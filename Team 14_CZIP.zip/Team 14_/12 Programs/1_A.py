import pandas as pd
import numpy as np
from sklearn.ensemble import StackingClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.metrics import accuracy_score, precision_score, f1_score, recall_score, roc_curve, auc
import matplotlib.pyplot as plt

from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB

data = pd.read_csv(r'D:\Python\Project\Dataset\ASNM-CDX-2009.csv', sep = ';')
y = data.iloc[:, 1]
X = data.iloc[:, 2:]

y = [int(bool(i)) for i in y]
y = np.array(y)

encoder = LabelEncoder()
X['label_poly'] = encoder.fit_transform(X['label_poly'].astype(str))
X['SrcIP'] = encoder.fit_transform(X['SrcIP'].astype(str))
X['DstIP'] = encoder.fit_transform(X['DstIP'].astype(str))
X['SrcMAC'] = encoder.fit_transform(X['SrcMAC'].astype(str))
X['DstMAC'] = encoder.fit_transform(X['DstMAC'].astype(str))
X['SrcIPInVlan'] = X['SrcIPInVlan'].astype(np.int32)
X['DstIPInVlan'] = X['DstIPInVlan'].astype(np.int32)
X.iloc[:, 535] = X.iloc[:, 535].astype(np.int32)
X.iloc[:, 569] = X.iloc[:, 569].astype(np.int32)


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state = 101)

scaler = StandardScaler().fit(X_train)
X_train = scaler.transform(X_train)
X_test = scaler.transform(X_test)

level0 = list()
##level0.append(('knn', KNeighborsClassifier()))
level0.append(('cart', DecisionTreeClassifier()))
level0.append(('svm', SVC()))
level0.append(('nb', GaussianNB())) 
level1 = KNeighborsClassifier()


model = StackingClassifier(estimators=level0, final_estimator=level1, cv=5)
model.fit(X_train, y_train)
y_pred = model.predict(X_test).round()

a = confusion_matrix(y_test, y_pred)
print(a)
print('Classification Report:\n', classification_report(y_test, y_pred))
print('Training Accuracy : {:.2f}%'.format(accuracy_score(model.predict(X_train).round(), y_train) * 100))
print('Testing Accuracy : {:.2f}%'.format(accuracy_score(y_pred, y_test) * 100))
print('Sensitivity: {:.2f}'.format(a[1][1]/(a[1][0]+a[1][1])))
print('Specificity: {:.2f}'.format(a[0][0]/(a[0][0]+a[0][1])))
print('Precision: {:.2f}'.format(precision_score(y_test, y_pred)))
print('F1 Score: {:.2f}'.format(f1_score(y_test, y_pred)))
print('Recall: {:.2f}'.format(recall_score(y_test, y_pred)))

y_pred_keras = model.predict(X_test).ravel()
fpr_keras, tpr_keras, thresholds_keras = roc_curve(y_test, y_pred_keras)

auc_keras = auc(fpr_keras, tpr_keras)

plt.figure(1)
plt.plot([0, 1], [0, 1], 'k--')
plt.plot(fpr_keras, tpr_keras, label='Naive Bayes (area = {:.3f})'.format(auc_keras))
plt.xlabel('False positive rate')
plt.ylabel('True positive rate')
plt.title('ROC curve')
plt.legend(loc='best')
plt.show()
plt.show()